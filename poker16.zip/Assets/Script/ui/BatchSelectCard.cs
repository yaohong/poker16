﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatchSelectCard : MonoBehaviour
{
	/*
	private bool inTouchState = false;
	private Vector2 firstTouchPos = Vector2.zero;

	void Update () 
	{
		int currentTouchCount = Input.touchCount;

		if (inTouchState) 
		{
			DragFigner ();

			if (currentTouchCount == 0) 
			{
				// release 	
				inTouchState = false;
			}
		} 
		else 
		{
			if (currentTouchCount == 1) 
			{
				inTouchState = true;
				firstTouchPos = Input.GetTouch (0).position;

				//UICamera.currentCamera.ra
				UICamera.Raycast( 
			}
			else 
			{
				// skip
			}
		}
	}

	void DragFigner()
	{
		Vector2 currentPosition = Input.GetTouch (0).position;
		// firstTouchPos
		UICamera.currentCamera.ScreenToWorldPoint(
	} */
}
